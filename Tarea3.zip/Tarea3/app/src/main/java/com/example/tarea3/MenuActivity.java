package com.example.tarea3;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.Instrumentation;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MenuActivity extends AppCompatActivity {

    private TextView txt,
                     txt2;
    private ImageButton img1,
                        img2,
                        img3;
    private static final int HOB = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Intent i = getIntent();

        this.txt = findViewById(R.id.msgHello);
        this.txt.setText("Hi " + i.getStringExtra("Name"));

        this.txt2 = findViewById(R.id.hobbyHid);

        this.img1 = findViewById(R.id.message);
        this.img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(),Message.class);
                startActivity(i);
            }
        });

        this.img2 = findViewById(R.id.hobbies);
        this.img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(),Hobbies.class);
                startActivityForResult(i, HOB);
            }
        });

        this.img3 = findViewById(R.id.friends);
        this.img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(),Friends.class);
                startActivity(i);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == HOB && resultCode == Activity.RESULT_OK) {
            this.txt2.setText(data.getStringExtra("Name"));
        }
    }
}