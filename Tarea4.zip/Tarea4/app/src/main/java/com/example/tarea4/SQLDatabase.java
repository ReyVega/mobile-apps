package com.example.tarea4;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class SQLDatabase extends SQLiteOpenHelper {
    private static SQLDatabase instance;
    private static final String DB_NAME = "HW4.db";
    private static final int VERSION = 1;

    public static synchronized SQLDatabase getInstance(Context context) {
        if (instance == null) {
            instance = new SQLDatabase(context.getApplicationContext());
        }
        return instance;
    }

    public SQLDatabase(@Nullable Context context) {
        super(context, DB_NAME, null, VERSION);
    }

    private static final String GREETINGS_TABLE = "CREATE TABLE GREETINGS(" +
                                                "ID INTEGER PRIMARY KEY," +
                                                "NAME TEXT" +
                                                ")";

    private static final String HOBBIES_TABLE = "CREATE TABLE HOBBIES(" +
                                                "ID INTEGER PRIMARY KEY," +
                                                "NAME TEXT" +
                                                ")";

    private static final String FRIENDS_TABLE = "CREATE TABLE FRIENDS(" +
                                                "ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                                                "FRIENDS TEXT," +
                                                "HOBBY TEXT" +
                                                ")";

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(GREETINGS_TABLE);
        db.execSQL(HOBBIES_TABLE);
        db.execSQL(FRIENDS_TABLE);

        db.execSQL("INSERT INTO GREETINGS VALUES(1, 'Hello!')");
        db.execSQL("INSERT INTO GREETINGS VALUES(2, 'Welcome!')");
        db.execSQL("INSERT INTO HOBBIES VALUES(1, '')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
