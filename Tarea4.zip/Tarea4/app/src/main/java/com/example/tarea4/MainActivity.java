package com.example.tarea4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    private Button buttonHobby,
                   buttonFriends;
    private TextView greeting1,
                     greeting2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SQLDatabase dbHelper = SQLDatabase.getInstance(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor c = db.rawQuery("SELECT NAME FROM GREETINGS", null);
        c.moveToFirst();

        this.greeting1 = findViewById(R.id.greeting1);
        this.greeting1.setText(c.getString(c.getColumnIndex("NAME")));
        c.moveToNext();

        this.greeting2 = findViewById(R.id.greeting2);
        this.greeting2.setText(c.getString(c.getColumnIndex("NAME")));
        c.close();

        this.buttonHobby = findViewById(R.id.buttonHobbies);
        this.buttonHobby.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), Hobbies.class);
                startActivity(i);
            }
        });
        this.buttonFriends = findViewById(R.id.buttonFriends);
        this.buttonFriends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(v.getContext(), Friends.class);
                startActivity(i);
            }
        });
    }
}