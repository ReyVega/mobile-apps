package com.example.tarea4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Friends extends AppCompatActivity {

    private Button buttonSaveF,
                   buttonSearch,
                   buttonDelete,
                   buttonReturnF;

    private EditText editFriend,
                     editHobbyF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);

        SQLDatabase dbHelper = SQLDatabase.getInstance(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        this.editFriend = findViewById(R.id.editFriend);
        this.editHobbyF = findViewById(R.id.editHobbyF);

        this.buttonSaveF = findViewById(R.id.buttonSaveF);
        this.buttonSaveF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!(editFriend.getText().toString().trim().equals("") || editHobbyF.getText().toString().trim().equals(""))) {
                    ContentValues cv = new ContentValues();
                    cv.put("FRIENDS", editFriend.getText().toString());
                    cv.put("HOBBY", editHobbyF.getText().toString());
                    db.insert("FRIENDS", null, cv);
                    Toast.makeText(getBaseContext(), "Friend saved", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getBaseContext(), "Insert data please", Toast.LENGTH_LONG).show();
                }
            }
        });
        this.buttonSearch = findViewById(R.id.buttonSearch);
        this.buttonSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!editFriend.getText().toString().trim().equals("")) {
                    Cursor c = db.rawQuery("SELECT HOBBY FROM FRIENDS WHERE FRIENDS='" + editFriend.getText().toString() +"'", null);
                    if (c.moveToFirst()) {
                        editHobbyF.setText(c.getString(0));
                        Toast.makeText(getBaseContext(), "Friend found", Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(getBaseContext(), "Friend not found", Toast.LENGTH_LONG).show();
                    }
                } else {
                    Toast.makeText(getBaseContext(), "Insert name please", Toast.LENGTH_LONG).show();
                }
            }
        });
        this.buttonDelete = findViewById(R.id.buttonDelete);
        this.buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!editFriend.getText().toString().trim().equals("")) {
                    db.delete("FRIENDS", "FRIENDS='" + editFriend.getText().toString() + "'" ,null);
                    Toast.makeText(getBaseContext(), "Friend deleted", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getBaseContext(), "Insert name please", Toast.LENGTH_LONG).show();
                }
            }
        });
        this.buttonReturnF = findViewById(R.id.buttonReturnF);
        this.buttonReturnF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}