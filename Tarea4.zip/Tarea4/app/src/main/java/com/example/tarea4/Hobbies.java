package com.example.tarea4;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class Hobbies extends AppCompatActivity {

    private Button buttonSaveH,
                   buttonReturnH;
    private TextView hobbyView;
    private EditText editHobby;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hobbies);

        SQLDatabase dbHelper = SQLDatabase.getInstance(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor c = db.rawQuery("SELECT NAME FROM HOBBIES", null);
        c.moveToFirst();

        this.hobbyView = findViewById(R.id.hobbyView);
        this.hobbyView.setText(c.getString(c.getColumnIndex("NAME")));

        this.editHobby = findViewById(R.id.editHobby);

        this.buttonSaveH = findViewById(R.id.buttonSaveH);
        this.buttonSaveH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hobbyView.setText(editHobby.getText().toString());
                db.execSQL("UPDATE HOBBIES SET NAME='" + editHobby.getText().toString() + "' WHERE ID = 1");
                Toast.makeText(getBaseContext(),"Hobby saved", Toast.LENGTH_LONG).show();
            }
        });

        this.buttonReturnH = findViewById(R.id.buttonReturnH);
        this.buttonReturnH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}