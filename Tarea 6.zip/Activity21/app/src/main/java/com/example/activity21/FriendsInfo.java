package com.example.activity21;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FriendsInfo extends AppCompatActivity {

    private TextView friendName,
                     hobbyName,
                     age,
                     phone,
                     address;
    private Button btnClose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends_info);

        this.friendName = findViewById(R.id.friendName);
        this.hobbyName = findViewById(R.id.hobbyName);
        this.age = findViewById(R.id.age);
        this.phone = findViewById(R.id.phone);
        this.address = findViewById(R.id.address);
        this.btnClose = findViewById(R.id.btnClose);

        Intent i = getIntent();

        this.friendName.setText(i.getStringExtra("name"));
        this.hobbyName.setText(i.getStringExtra("hobby"));
        this.age.setText(i.getStringExtra("age"));
        this.phone.setText(i.getStringExtra("phone"));
        this.address.setText(i.getStringExtra("address"));

        this.btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}