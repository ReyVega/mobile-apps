package com.example.activity21;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements  Handler.Callback, ListAdapter.onItemListener {

    private Handler handler;
    private Button loadBtn;
    private ListAdapter la;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.handler = new Handler(Looper.getMainLooper(), this);
        this.loadBtn = findViewById(R.id.loadBtn);

        this.loadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doRequest();
            }
        });

        List<ListElement> list = new ArrayList<ListElement>();
        this.la = new ListAdapter(list, MainActivity.this, this);
        RecyclerView rv = findViewById(R.id.recyclerView);
        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        rv.setAdapter(this.la);
    }

    public void doRequest() {
        Request req = new Request("https://raw.githubusercontent.com/ReyVega/mobile-apps/main/friends.json", this.handler);
        req.start();
    }

    @Override
    public boolean handleMessage(@NonNull Message msg) {
        this.la.updateListJSON(msg.obj.toString());
        return false;
    }

    @Override
    public void onItemClick(int pos) {
        ListElement le = this.la.getElementList(pos);

        Intent i = new Intent(this, FriendsInfo.class);
        i.putExtra("name", le.getFriend());
        i.putExtra("hobby", le.getHobby());
        i.putExtra("age", le.getAge());
        i.putExtra("phone", le.getPhone());
        i.putExtra("address", le.getAddress());

        startActivity(i);
    }
}