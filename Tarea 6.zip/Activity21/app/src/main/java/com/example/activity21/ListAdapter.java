package com.example.activity21;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class ListAdapter extends RecyclerView.Adapter<ListAdapter.ViewHolder> {
    private List<ListElement> items;
    private LayoutInflater inflater;
    private Context context;
    private onItemListener onItemListener;

    public ListAdapter(List<ListElement> items, Context context, onItemListener onItemListener) {
        this.inflater = LayoutInflater.from(context);
        this.context = context;
        this.items = items;
        this.onItemListener = onItemListener;
    }

    @Override
    public int getItemCount() {
        return this.items == null ? 0 : this.items.size();
    }

    @Override
    public ListAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = this.inflater.inflate(R.layout.list_element, null);
        return new ListAdapter.ViewHolder(v, this.onItemListener);
    }

    @Override
    public void onBindViewHolder(final ListAdapter.ViewHolder holder, final int position) {
        holder.bindData(this.items.get(position));
    }

    public void setItems(List<ListElement> items) {
        this.items = items;
    }

    public void updateList (List<ListElement> newList) {
        if (newList != null && newList.size() > 0) {
            this.items.clear();
            this.items.addAll(newList);
            notifyDataSetChanged();
        }
    }

    public void updateListJSON (String json) {
        try {
            JSONArray data = new JSONArray(json);
            List<ListElement> newList = new ArrayList<ListElement>();

            for (int i = 0; i < data.length(); i++) {
                JSONObject object = data.getJSONObject(i);
                String nameFriend = object.getString("name"),
                        nameHobby = object.getString("hobby"),
                        age = object.getString("age"),
                        phone = object.getString("phone"),
                        address = object.getString("address");
                newList.add(new ListElement(nameFriend, nameHobby, age, phone, address));
            }
            updateList(newList);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public ListElement getElementList (int pos) {
        if (this.items != null && pos > -1 && pos <= this.items.size() - 1) {
            return this.items.get(pos);
        } else {
            return null;
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView friend,
                 hobby;
        onItemListener onItemListener;

        ViewHolder(View itemView, onItemListener onItemListener) {
            super(itemView);
            this.onItemListener = onItemListener;
            this.friend = itemView.findViewById(R.id.friend);
            this.hobby = itemView.findViewById(R.id.hobby);

            itemView.setOnClickListener(this);
        }

        void bindData(final ListElement item) {
            this.friend.setText(item.getFriend());
            this.hobby.setText(item.getHobby());
        }

        @Override
        public void onClick(View v) {
            this.onItemListener.onItemClick(getAdapterPosition());
        }
    }

    public interface onItemListener {
        void onItemClick(int pos);
    }
}
